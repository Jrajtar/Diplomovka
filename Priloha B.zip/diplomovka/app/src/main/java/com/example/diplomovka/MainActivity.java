package com.example.diplomovka;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class MainActivity extends AppCompatActivity implements OnMapReadyCallback, View.OnClickListener {
    private static final int MY_PERMISSIONS_REQUEST_RECEIVE_SMS = 0;
    private static final String SMS_RECEIVED = "android.provider.Telephony.SMS_RECEIVED";

    GoogleMap map;
    private boolean navigation = false;
    public String lat, log;
    private String send_data, number = "phone number of mobile";
    TextView messageTV;

    SmsReceiver receiver = new SmsReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            super.onReceive(context, intent);
//            replace x with phone number used in gsm
            if (phoneNo.equals("xxxxxxxx") || phoneNo.equals("xxxxxxxxx")) {
                if (msg.contains("Poloha:")) {
                    msg = msg.replace("Poloha:", "");
                    System.out.println(msg);
                    String[] result = msg.split(",");
                    double Lat1 = Double.parseDouble(result[0]);
                    double Lon2 = Double.parseDouble(result[1]);
                    LatLng found = new LatLng(Lat1, Lon2);

                    MarkerOptions markerOptions = new MarkerOptions();
                    // Toast.makeText(getApplicationContext(), Lat.toString()+Lon.toString(), Toast.LENGTH_LONG).show();
                    markerOptions.position(found);
                    markerOptions.title("Tu je auto");
                    map.clear();
                    map.animateCamera(CameraUpdateFactory.newLatLngZoom(found, 15));
                    map.addMarker(markerOptions);
                    messageTV.setText("Auto lokalizovane");
                    navigation = false;
                } else if (msg.contains("Ciel")) {
                    navigation = false;
                    messageTV.setText(msg);
                } else {
                    messageTV.setText(msg);
                }

            } else {
                System.out.println("NEJDE");
            }
        }
    };

    @Override
    protected void onPostResume() {
        super.onPostResume();
        registerReceiver(receiver, new IntentFilter(SMS_RECEIVED));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(receiver);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        messageTV = findViewById(R.id.status);

        ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.SEND_SMS, Manifest.permission.READ_SMS, Manifest.permission.READ_PHONE_STATE, Manifest.permission.RECEIVE_SMS}, PackageManager.PERMISSION_GRANTED);
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS) != PackageManager.PERMISSION_GRANTED) {

            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.RECEIVE_SMS)) {
                // Do nothing as user has denied
            } else {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECEIVE_SMS}, MY_PERMISSIONS_REQUEST_RECEIVE_SMS);
            }
        }
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        Button gps = findViewById(R.id.gps);
        Button set_home = findViewById(R.id.set);
        Button home = findViewById(R.id.home);
        Button navigate = findViewById(R.id.nav);
        Button calibrate = findViewById(R.id.cal);

        gps.setOnClickListener(this);
        set_home.setOnClickListener(this);
        home.setOnClickListener(this);
        navigate.setOnClickListener(this);
        calibrate.setOnClickListener(this);

    } //onCreate


    private void sendSMS(String message) {

        SmsManager mySmsManager = SmsManager.getDefault();
        mySmsManager.sendTextMessage(number, null, message, null, null);

    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        map = googleMap;

        LatLng beginPoint = new LatLng(48.306146, 18.076589);
        map.animateCamera(CameraUpdateFactory.newLatLngZoom(beginPoint, 10), 3000, null);

        map.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
            @Override
            public void onMapClick(@NonNull LatLng latLng) {
                MarkerOptions markerOptions = new MarkerOptions();
                markerOptions.position(latLng);
                markerOptions.title(latLng.latitude + " " + latLng.longitude);
                System.out.println();
                lat = Double.toString(latLng.latitude).substring(0, 9);
                System.out.println(lat);
                log = Double.toString(latLng.longitude).substring(0, 9);
                System.out.println(log);
                map.clear();
                map.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 15));
                map.addMarker(markerOptions);
                navigation = true;

            }
        });
    }

    @Override
    public void onClick(View view) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(MainActivity.this
                    , Manifest.permission.SEND_SMS)
                    == PackageManager.PERMISSION_GRANTED) {
                switch (view.getId()) {
                    case R.id.gps:
                        messageTV.setText("Zistujem Polohu");
                        sendSMS("gps");
                        break;
                    case R.id.set:
                        sendSMS("set");
                        break;
                    case R.id.home:
                        sendSMS("home");
                        break;
                    case R.id.nav:
                        if (navigation == true) {
                            Toast.makeText(this, "Navigujem", Toast.LENGTH_SHORT).show();
                            send_data = "go:" + lat + "," + log + "*";
                            System.out.println(send_data);
                            sendSMS(send_data);
                            map.clear();
                            messageTV.setText("Navigujem");
                            send_data = "";
                        } else messageTV.setText("Vyber Ciel");
                        break;
                    case R.id.cal:
                        messageTV.setText("Kalibracia");
                        sendSMS("calibrate");
                        break;
                }
            } else {
                ActivityCompat.requestPermissions(MainActivity.this
                        , new String[]{Manifest.permission.SEND_SMS}
                        , 100);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case 100:
                if ((grantResults.length > 0) && (grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
                    sendSMS(send_data);
                    map.clear();
                    send_data = "";
                }
                break;
            case MY_PERMISSIONS_REQUEST_RECEIVE_SMS:
                if ((grantResults.length > 0) && (grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
                    Toast.makeText(this, "Broadcast enabled", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(this, "Broadcast denied !", Toast.LENGTH_LONG).show();
                }
                break;
            default:
                break;
        }
    }
}
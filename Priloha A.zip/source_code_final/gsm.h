//GSM
//------------------------------------------------------------------------------------
#include <NeoSWSerial.h>

#define gsmPort_RX 2
#define gsmPort_TX 3

#include <NeoSWSerial.h>
//Create software serial object to communicate with gsmPort
NeoSWSerial gsmPort(3, 2); //gsmPort Tx & Rx is connected to Arduino #3 & #2
//------------------------------------------------------------------------------------
String msg, data_reply;
char Received_SMS;              //Here we store the full received SMS (with phone sending number and date/time) as char

void updateSerial()
{
  delay(500);
  while (Serial.available())
  {
    gsmPort.write(Serial.read());//Forward what Serial received to Software Serial Port
  }
  while (gsmPort.available())
  {
    Serial.write(gsmPort.read());//Forward what Software Serial received to Serial Port
  }
}

void receiveMode() {      //Set the gsmPort Receive mode

  gsmPort.println("AT"); //If everything is Okay it will show "OK" on the serial monitor
  updateSerial();
  gsmPort.println("AT+CMGF=1"); // Configuring TEXT mode
  updateSerial();
  gsmPort.println("AT+CNMI=2,2,0,0,0"); //Configure the gsmPort on how to manage the Received SMS... Check the gsmPort AT commands manual
  updateSerial();
}

void setupGSM()
{
  //Begin serial communication with Arduino and gsmPort
  gsmPort.begin(9600);

  //  Serial.println("Initializing...");
  delay(1000);

  receiveMode();
  delay(1000);
}

void send_msg(String msg) {
  gsmPort.println("AT+CMGF=1");    //Sets the GSM Module in Text Mode
  delay(500);  // Delay of 500 milli seconds or 1 second
  gsmPort.println("AT+CMGS=\"xxxxxxxxxxx\"\r"); // Replace x with mobile number
  delay(500);
  //  gsmPortSerial->println("Poloha:");
  gsmPort.print(msg);
  delay(100);
  gsmPort.println((char)26);// ASCII code of CTRL+Z
  delay(1000);
  receiveMode();
}

void scan_sms() {
  String msg;             //We add this new variable String type, and we put it in loop so everytime gets initialized

  while (gsmPort.available() > 0) {   //When gsmPort sends something to the Arduino... problably the SMS received... if something else it's not a problem

    Received_SMS = gsmPort.read(); //"char Received_SMS" is now containing the full SMS received
    Serial.print(Received_SMS);   //Show it on the serial monitor (optional)
    msg.concat(Received_SMS);    
  }

  if (msg.indexOf("gps") != -1) {
    data_reply = "Poloha:" + String(latc, 6) + "," + String(logc, 6);
    send_msg(data_reply);
    data_reply = "";
  }
  else if (msg.indexOf("go:") != -1 && msg.lastIndexOf("*") != -1) {
    msg = msg.substring(msg.lastIndexOf("go:"));
    //    Serial.print("Raw data: " + msg);
    //        Serial.println(msg.lastIndexOf(":"));
    latd = msg.substring(msg.lastIndexOf("go:") + 3, msg.indexOf(",")).toFloat();
    logd = msg.substring(msg.lastIndexOf(",") + 1, msg.lastIndexOf("*")).toFloat();
    navigation = 1;
    //    Serial.println("Lat: " + String(latd, 6) + " Log: " +  String(logd, 6));
  }
  else if (msg.indexOf("home") != -1) {
    latd = lath;
    logd = logh;
    navigation = 1;
    send_msg("Home activated");
    delay(1000);
  }
  else if (msg.indexOf("calibrate") != -1) {
    calibration = 1;
  }
  else if (msg.indexOf("set") != -1) {
    lath = latc;
    logh = logc;
    send_msg("Home update");
    delay(1000);
  }
}

//GPS Heading:-

void gpsheading()
{
  float x, y, deltalog, deltalat;
  deltalog = logd - logc;
  deltalat = latd - latc;

  x = cos(latd) * sin(deltalog);
  y = (cos(latc) * sin(latd)) - (sin(latc) * cos(latd) * cos(deltalog));

  bearing = (atan2(x, y));
  Serial.print("bearing");
  Serial.println(bearing);
  if (bearing < 0.0)
  {
    bearing += TWO_PI;
  }
  targetHeading = degrees(bearing);

  Serial.print(F("Error: "));
  Serial.println(headingError);
}

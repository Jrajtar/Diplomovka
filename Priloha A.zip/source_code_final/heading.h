//Heading:-
//#include <Adafruit_Sensor.h>
//#include <Adafruit_HMC5883_U.h>

/* Assign a unique ID to this sensor at the same time */
//Adafruit_HMC5883_Unified mag = Adafruit_HMC5883_Unified(12345);

#include <HMC5883L.h>

HMC5883L compass;


//float declinationAngle = 0.09;
int minX = 0;
int maxX = 0;
int minY = 0;
int maxY = 0;

int calibration = 0;

int offX = 0;
int offY = 0;

void setupCompass()
{
  // Initialize Initialize HMC5883L
  while (!compass.begin())
  {
    delay(500);
  }

  // Set measurement range
  compass.setRange(HMC5883L_RANGE_1_3GA);

  // Set measurement mode
  compass.setMeasurementMode(HMC5883L_CONTINOUS);

  // Set data rate
  compass.setDataRate(HMC5883L_DATARATE_30HZ);

  // Set number of samples averaged
  compass.setSamples(HMC5883L_SAMPLES_8);

  compass.setOffset(offX, offY);
}

void compass_calibrate()
{
  Vector mag = compass.readRaw();

  // Determine Min / Max values
  if (mag.XAxis < minX) minX = mag.XAxis;
  if (mag.XAxis > maxX) maxX = mag.XAxis;
  if (mag.YAxis < minY) minY = mag.YAxis;
  if (mag.YAxis > maxY) maxY = mag.YAxis;

  // Calculate offsets
  offX = (maxX + minX) / 2;
  offY = (maxY + minY) / 2;

  //  Serial.print(offX);
  //  Serial.print(F(":"));
  //  Serial.print(offY);
  //  Serial.print(F("\n"));
}


void headingcal()
{
  Vector norm = compass.readNormalize();

  // Calculate heading
  heading = atan2(norm.YAxis, norm.XAxis);

  // Set declination angle on your location and fix heading
  // You can find your declination on: http://magnetic-declination.com/
  // (+) Positive or (-) for negative
  // Formula: (deg + (min / 60.0)) / (180 / M_PI);
  //  float declinationAngle = (5 + (23.0 / 60.0)) / (180 / M_PI);
  float declinationAngle = 0.09;
  heading += declinationAngle;

  // Correct for heading < 0deg and heading > 360deg
  if (heading < 0)  heading += 2 * PI;
  if (heading > 2 * PI) heading -= 2 * PI;

  // Convert to degrees
  float headingDegrees = heading * 180 / M_PI;
  currentHeading = headingDegrees;

  // Output
  //  Serial.print(offX);
  //  Serial.print(F(":"));
  //  Serial.print(offY);
  //  Serial.print(F("\n"));
  //  Serial.println();
  //
  //  Serial.print(F(" Heading = "));
  //  Serial.print(heading);
  //  Serial.print(F(" Degress = "));
  //  Serial.print(headingDegrees);
  //  Serial.println();

}

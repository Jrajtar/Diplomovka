//Motor:-

void carGO(int vel_left, int vel_right)
{
  if (vel_left < 0)
  {
    digitalWrite(right_backward, HIGH);
    digitalWrite(left_forward, LOW);
    vel_left = -1 * vel_left;
  }
  else
  {
    digitalWrite(right_backward, LOW);
    digitalWrite(left_forward, HIGH);
  }
  analogWrite(left_motor, vel_left);

  if (vel_right < 0)
  {
    digitalWrite(right_backward, HIGH);
    digitalWrite(right_forward, LOW);
    vel_right = -1 * vel_right;
  }
  else
  {
    digitalWrite(right_backward, LOW);
    digitalWrite(right_forward, HIGH);
  }
  analogWrite(right_motor, vel_right);
}

void forward()
{
  digitalWrite(right_forward, HIGH);
  analogWrite(right_motor, velocity);

  digitalWrite(left_forward, HIGH);
  analogWrite(left_motor, velocity);
}

void right()
{
  analogWrite(right_motor, velocity);
  digitalWrite(right_backward, HIGH);

  analogWrite(left_motor, velocity);
  digitalWrite(left_forward, HIGH);
}

void slow_right()
{
  analogWrite(right_motor, 90);
  digitalWrite(right_backward, HIGH);

  analogWrite(left_motor, 90);
  digitalWrite(left_forward, HIGH);
}

void left()
{
  analogWrite(right_motor, velocity);
  digitalWrite(right_forward, HIGH);

  analogWrite(left_motor, velocity);
  digitalWrite(left_backward, HIGH);
}

void slow_left()
{
  analogWrite(right_motor, 90);
  digitalWrite(right_forward, HIGH);

  analogWrite(left_motor, 90);
  digitalWrite(left_backward, HIGH);
}

void back()
{
  analogWrite(right_motor, velocity);
  digitalWrite(right_backward, HIGH);

  analogWrite(left_motor, velocity);
  digitalWrite(left_backward, HIGH);
}
void stop1()
{

  digitalWrite(right_forward, LOW);
  digitalWrite(right_backward, LOW);
  analogWrite(right_motor, 0);


  digitalWrite(left_forward, LOW);
  digitalWrite(left_backward, LOW);
  analogWrite(left_motor, 0);

}

int error_output;
void steering() {
  distance_to_home = TinyGPSPlus::distanceBetween(latc, logc, latd, logd);
  // calculate where we need to turn to head to destination
  headingError = targetHeading - currentHeading;
  if (distance_to_home <= 3) {
    stop1();
    navigation = 0;
    finish = 1;
  }

  // adjust for compass wrap
  if (headingError < -180)
    headingError += 360;
  if (headingError > 180)
    headingError -= 360;

  // calculate which way to turn to intercept the targetHeading
  if (abs(headingError) <= HEADING_TOLERANCE)      // if within tolerance, don't turn
    error_output = 0;
  else if (headingError < 60 && headingError > -60)
  {
    error_output = headingError;
  }
  else if (headingError >= 60)
    error_output = 100;
  else if (headingError <= -60)
    error_output = -100;

  if (navigation == 1) {
    if (error_output == 0)
    {
      carGO(200, 200); //0-255
    }
    else if (error_output < 60)
    {
      if (error_output < 0)
        carGO(150 + error_output, 150);
      else
        carGO(150, 150 - error_output);
    }
    else if (error_output == 100)
    {
      carGO(150, -150); //0-255
    }
    else if (error_output == -100)
    {
      carGO(150, -150); //0-255
    }
  }
}

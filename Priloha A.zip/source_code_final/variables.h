// Compass navigation
int targetHeading;              // where we want to go to reach current waypoint
int currentHeading;             // where we are actually facing now
int headingError;               // signed (+/-) difference between targetHeading and currentHeading
#define HEADING_TOLERANCE 5     // tolerance +/- (in degrees) within which we don't attempt to turn to intercept targetHeading

// Ultrasonic ping sensor
#define TRIGGER_PIN 4
#define ECHO_PIN 5
#define MAX_DISTANCE_CM 250                        // Maximum distance we want to ping for (in CENTIMETERS). Maximum sensor distance is rated at 400-500cm.  
#define MAX_DISTANCE_IN (MAX_DISTANCE_CM / 2.5)    // same distance, in inches

// Object avoidance distances (in inches)
#define SAFE_DISTANCE 70
#define TURN_DISTANCE 40
#define STOP_DISTANCE 12

//Navigation
float lath, logh, latd, logd, latc, logc;
double lat_val, lng_val, alt_m_val;
bool loc_valid, alt_valid;
unsigned long distance_to_home;
int navigation = 0;
int finish = 0;
//float latd=48.349481,logd=18.415471;
//float latc=48.349781,logc=18.415403;
float bearing;
float heading;
//Navigation

//Motor setup
const int right_motor = 9;    //enable right motors(ENA)
const int right_forward = 7;    //right forward(IN1)
const int right_backward = 8;    //right backward(IN2)
const int left_forward = 11;   //left forward(IN3)
const int left_backward = 12;   //left backward(IN4)
const int left_motor = 10;   //enable left motors(ENB)
const int servo = 6;
int velocity = 150;
//Motor setup

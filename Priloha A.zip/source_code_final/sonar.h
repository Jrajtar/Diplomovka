//#include <Adafruit_HMC5883_U.h>

#include <NewPing.h>
int sonarDistance;
NewPing sonar(TRIGGER_PIN, ECHO_PIN, MAX_DISTANCE_CM);     // NewPing setup of pins and maximum distance.

void checkSonar(void)
{
  int dist;

  dist = sonar.ping_in();
  if (dist == 0)
    dist = MAX_DISTANCE_IN;
  sonarDistance = dist;
  Serial.println(sonarDistance);

}

void moveAndAvoid(void)
{
  if (sonarDistance <  TURN_DISTANCE && sonarDistance > STOP_DISTANCE)  // getting close, time to turn to avoid object
  {
    stop1();

    if (error_output < 60)
    {
      if (error_output < 0) {
        left();
        delay(200);
      }
      else {
        right();
        delay(200);
      }
    }
    else if (error_output == 100)
    {
      right(); //0-255
      delay(200);
    }
    else if (error_output == -100)
    {
      right(); //0-255
      delay(200);
    }
    return;
  }

  if (sonarDistance <  STOP_DISTANCE)          // too close, stop and back up
  {
    stop1();
    back();
    while (sonarDistance < TURN_DISTANCE)       // backup until we get safe clearance
    {
      if (gps.location.isValid())
        gpsdata();
      headingcal();
      // get our current heading
      gpsheading();
      checkSonar();
      delay(100);
    }
    stop1();
    return;
  }
}

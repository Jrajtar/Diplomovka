//GPS:-
#include<TinyGPS++.h>
TinyGPSPlus gps;

#define gpsPort Serial // GPS TX connected to Arduino RX pin 0

//float latc, logc, lath, logh;
//double lat_val, lng_val, alt_m_val;
//bool loc_valid, alt_valid;

static void smartDelay(unsigned long ms)
{
  unsigned long start = millis();
  do
  {
    while (gpsPort.available())
      gps.encode(gpsPort.read());
  } while (millis() - start < ms);
}

void setupGPS()
{
  //  Serial.println(F("GPS init..."));
  boolean gps_setup = 1;
  while (gps_setup)
  {
    while (gpsPort.available() > 0)
    {
      gps.encode(gpsPort.read());
      if (lat_val = gps.location.lat() != 0.0 && gps.location.lng() != 0.0) {
        gps_setup = 0;
      }
    }
    delay(500);
  }
  //  Serial.println(F("GPS Ready"));
  delay(1000);
}

void gpsdata()
{
  smartDelay(200);
  unsigned long start;

  if (gps.location.isValid())
  {
    lat_val = gps.location.lat();
    lng_val = gps.location.lng();
  }
  //  unsigned long distance_to_home;
  //  lat_val = gps.location.lat();
  //  loc_valid = gps.location.isValid();
  //  lng_val = gps.location.lng();
  //  alt_m_val = gps.altitude.meters();
  //  alt_valid = gps.altitude.isValid();
  ////  Serial.println("Valid: " + String(loc_valid));
  //  if (!loc_valid)
  //  {
  ////    Serial.print(F("Latitude : "));
  ////    Serial.println(F("*****"));
  ////    Serial.print(F("Longitude : "));
  ////    Serial.println(F("*****"));
  ////    delay(100);
  //  }
  //  else
  //  {
  ////    Serial.println(F("GPS READING: "));
  ////    // DegMinSec(lat_val);
  ////    Serial.print(F("Latitude in Decimal Degrees : "));
  ////    Serial.println(lat_val, 6);
  ////
  ////    //DegMinSec(lng_val);
  ////    Serial.print(F("Longitude in Decimal Degrees : "));
  ////    Serial.println(lng_val, 6);
  ////    delay(100);
  //  }
  //  distance_to_home = TinyGPSPlus::distanceBetween(lat_val,lng_val,latd, logd);
  //  Serial.println(distance_to_home);
  latc = lat_val;
  logc = lng_val;
}
